from __future__ import annotations
import pandas as pd

from credit_risk.io import read_parquet, read_joblib, write_csv
from credit_risk.logging_utils import get_logger, log_event

def score_pipeline(input_path: str, artifacts_dir: str, output_path: str):
    logger = get_logger()

    df = read_parquet(input_path)

    bundle = read_joblib(artifacts_dir + "model.joblib")
    model = bundle["model"]
    platt = read_joblib(artifacts_dir + "platt.joblib")

    X = df.drop(["SK_ID_CURR"], axis=1)
    p_raw = model.predict_proba(X)[:, 1]
    p_cal = platt.predict(p_raw)

    out = pd.DataFrame(
        {
            "SK_ID_CURR": df["SK_ID_CURR"].values,
            "TARGET": p_cal,
        }
    )

    write_csv(out, str(output_path))
    log_event(logger, "score_done", rows=len(out), output=str(output_path))
    return out

